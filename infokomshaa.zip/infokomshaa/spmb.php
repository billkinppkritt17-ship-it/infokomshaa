<?php
require_once __DIR__ . '/includes/header.php';
$jur = $db->query('SELECT * FROM jurusan ORDER BY urutan,id')->fetchAll();
$gel = $db->query('SELECT * FROM gelombang ORDER BY urutan,id')->fetchAll();
$bidang = [];
foreach ($jur as $j) $bidang[$j['bidang']][] = $j;
?>
<section class="hero" id="beranda">
  <div class="blob b1"></div><div class="blob b2"></div>
  <div class="hero-text reveal">
    <span class="chip">Terakreditasi &ldquo;<?= e(cfg('akreditasi')) ?>&rdquo; &middot; <?= e(cfg('yayasan')) ?></span>
    <h1>SPMB</h1>
    <h2>Sistem Penerimaan Murid Baru</h2>
    <p class="ta">Tahun Ajaran <?= e(cfg('tahun_ajaran')) ?></p>
    <p class="lead"><?= e(cfg('nama_sekolah')) ?> <?= e(cfg('kota')) ?> membuka pendaftaran untuk empat bidang keahlian. Daftar online sekarang dan dapatkan bonus sesuai gelombang pendaftaran.</p>
    <div class="actions">
      <a class="btn btn-gold rip" href="<?= url('daftar.php') ?>">Daftar Online</a>
      <a class="btn btn-ghost rip" href="<?= url('formulir_pdf.php') ?>">Unduh Formulir PDF</a>
    </div>
  </div>
  <div class="hero-photo reveal">
    <div class="ring"><img src="<?= url('assets/images/gedung.jpg') ?>" alt="Gedung sekolah"></div>
    <img class="siswa" src="<?= url('assets/images/siswa.jpg') ?>" alt="Siswa">
    <span class="float f1">Free Laptop</span>
    <span class="float f2">Free SPP 3 Bulan</span>
    <span class="float f3">Free Seragam</span>
  </div>
</section>

<section class="sec" id="keahlian">
  <div class="head reveal"><span>Pilih Masa Depanmu</span><h2>Bidang Keahlian</h2><p>Klik salah satu kartu untuk melihat detail jurusan.</p></div>
  <?php foreach ($bidang as $nm => $list): ?>
    <h3 class="grp reveal"><?= e($nm) ?></h3>
    <div class="grid2">
      <?php foreach ($list as $j): ?>
        <article class="card jcard rip reveal" tabindex="0"
          data-nama="<?= e($j['nama']) ?>" data-singkat="<?= e($j['singkatan']) ?>" data-desc="<?= e($j['deskripsi']) ?>"
          data-img="<?= e(url($j['gambar'])) ?>" data-id="<?= (int)$j['id'] ?>">
          <img src="<?= e(url($j['gambar'])) ?>" alt="<?= e($j['singkatan']) ?>">
          <div><em><?= e($j['singkatan']) ?></em><h4><?= e($j['nama']) ?></h4><span class="more">Lihat detail &rarr;</span></div>
        </article>
      <?php endforeach; ?>
    </div>
  <?php endforeach; ?>
</section>

<section class="sec alt" id="gelombang">
  <div class="head reveal"><span>Jadwal &amp; Bonus</span><h2>Gelombang Pendaftaran</h2><p>Klik kartu gelombang untuk langsung mendaftar.</p></div>
  <div class="grid3">
    <?php foreach ($gel as $i => $g): ?>
      <article class="card gcard rip reveal" tabindex="0">
        <div class="num"><?= $i + 1 ?></div>
        <h4><?= e($g['nama']) ?></h4>
        <p class="tgl"><?= e($g['tanggal']) ?></p>
        <div class="bonus"><small>Bonus</small><b><?= e($g['bonus']) ?></b></div>
        <a class="go btn btn-blue" href="<?= url('daftar.php?g=' . (int)$g['id']) ?>">Daftar gelombang ini</a>
      </article>
    <?php endforeach; ?>
  </div>
</section>

<section class="sec" id="informasi">
  <div class="head reveal"><span>Hubungi Kami</span><h2>Informasi Pendaftaran</h2></div>
  <div class="grid4">
    <a class="info rip reveal" href="<?= e(wa_link()) ?>" target="_blank" rel="noopener"><b>WhatsApp</b><span><?= e(cfg('telepon')) ?></span></a>
    <a class="info rip reveal" href="https://instagram.com/<?= e(cfg('instagram')) ?>" target="_blank" rel="noopener"><b>Instagram</b><span><?= e(cfg('instagram')) ?></span></a>
    <a class="info rip reveal" href="https://<?= e(preg_replace('#^https?://#', '', cfg('website'))) ?>" target="_blank" rel="noopener"><b>Website</b><span><?= e(cfg('website')) ?></span></a>
    <div class="info rip reveal"><b>Alamat</b><span><?= e(cfg('alamat')) ?></span></div>
  </div>
  <div class="time reveal"><small>Waktu Pendaftaran</small><b><?= e(cfg('jam')) ?></b></div>
</section>

<div class="modal" id="modal" aria-hidden="true">
  <div class="modal-box">
    <button class="x" id="mx" aria-label="Tutup">&times;</button>
    <img id="m-img" alt="">
    <em id="m-s"></em><h3 id="m-n"></h3><p id="m-d"></p>
    <a class="btn btn-gold rip" id="m-go" href="<?= url('daftar.php') ?>">Daftar ke jurusan ini</a>
  </div>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
