<?php

require_once __DIR__ . '/config/koneksi.php';

/*
|--------------------------------------------------------------------------
| DATA PROFIL SEKOLAH
|--------------------------------------------------------------------------
*/

$profil = $koneksi->query("
    SELECT *
    FROM profil_sekolah
    LIMIT 1
")->fetch();

$namaSekolah = $profil['nama_sekolah'] ?? 'SMK Infokom r';


/*
|--------------------------------------------------------------------------
| BERITA TERBARU
|--------------------------------------------------------------------------
*/

$beritaTerbaru = $koneksi->query("
    SELECT *
    FROM berita
    ORDER BY tanggal DESC, id DESC
    LIMIT 3
")->fetchAll();


/*
|--------------------------------------------------------------------------
| GALERI TERBARU
|--------------------------------------------------------------------------
*/

$galeriTerbaru = $koneksi->query("
    SELECT *
    FROM galeri
    ORDER BY tanggal DESC, id DESC
    LIMIT 6
")->fetchAll();

?>

<?php require_once __DIR__ . '/includes/web_header.php'; ?>



<!-- =========================================================
     HERO
========================================================= -->

<section class="hero-s">

    <div class="container">

        <span class="hero-kop">
            WEBSITE RESMI SEKOLAH
        </span>

        <h1>
            Selamat Datang di<br>
            <?= htmlspecialchars($namaSekolah) ?>
        </h1>

        <p class="lead-s">
            Sekolah kejuruan yang membekali peserta didik
            dengan kompetensi, karakter, dan kesiapan
            menghadapi dunia kerja serta perkembangan teknologi.
        </p>

        <div class="hero-aksi">

            <a
                href="<?= BASE_URL ?>/profil.php"
                class="tombol tombol-utama"
            >
                Kenali Sekolah →
            </a>

            <a
                href="<?= BASE_URL ?>/spmb.php"
                class="tombol tombol-luar"
            >
                Informasi SPMB
            </a>

        </div>

    </div>

</section>


<!-- =========================================================
     STATISTIK
========================================================= -->

<section class="container">

    <div class="statistik">

        <div class="item">
            <span class="angka">4</span>
            <span class="label">Program Keahlian</span>
        </div>

        <div class="item">
            <span class="angka">6+</span>
            <span class="label">Program Sekolah</span>
        </div>

        <div class="item">
            <span class="angka">100%</span>
            <span class="label">Berbasis Kompetensi</span>
        </div>

        <div class="item">
            <span class="angka">1</span>
            <span class="label">Komitmen untuk Masa Depan</span>
        </div>

    </div>

</section>


<!-- =========================================================
     TENTANG SEKOLAH
========================================================= -->

<section class="bagian">

    <div class="container">

        <div class="judul-bagian">

            <span class="kop">
                TENTANG SEKOLAH
            </span>

            <h2>
                Mempersiapkan Generasi Siap Masa Depan
            </h2>

            <p>
                <?= htmlspecialchars(
                    mb_substr(
                        strip_tags(
                            $profil['sejarah']
                            ?? 'SMK Infokom Bogor merupakan sekolah kejuruan yang berkomitmen mengembangkan kompetensi peserta didik.'
                        ),
                        0,
                        500
                    )
                ) ?>
            </p>

            <a
                href="<?= BASE_URL ?>/profil.php"
                class="tombol tombol-utama tombol-kecil"
            >
                Selengkapnya →
            </a>

        </div>

    </div>

</section>


<!-- =========================================================
     JURUSAN
========================================================= -->

<section class="bagian bagian-jurusan">

    <div class="container">

        <div class="judul-bagian">

            <span class="kop">PROGRAM KEAHLIAN</span>

            <h2>Kenali Jurusan Kami</h2>

            <p>
                Pilih program keahlian sesuai minat, bakat, dan potensi
                untuk mempersiapkan masa depan di dunia pendidikan maupun kerja.
            </p>

        </div>

        <div class="grid-jurusan">

            <!-- DKV -->
            <article class="kartu-jurusan">

                <div class="foto-jurusan">
                    <img
                        src="<?= BASE_URL ?>/assets/images/dkv.png"
                        alt="Desain Komunikasi Visual"
                    >
                </div>

                <div class="isi-jurusan">

                    <span class="label-jurusan">
                        PROGRAM KEAHLIAN
                    </span>

                    <h3>Desain Komunikasi Visual</h3>

                    <p>
                        Mempelajari desain grafis, multimedia,
                        komunikasi visual, fotografi, videografi,
                        dan kreativitas digital.
                    </p>

                    <a
                        href="<?= BASE_URL ?>/jurusan.php"
                        class="link-jurusan"
                    >
                        Lihat Jurusan →
                    </a>

                </div>

            </article>


            <!-- PSPT -->
            <article class="kartu-jurusan">

                <div class="foto-jurusan">
                    <img
                        src="<?= BASE_URL ?>/assets/images/pspt.png"
                        alt="Produksi dan Siaran Program Televisi"
                    >
                </div>

                <div class="isi-jurusan">

                    <span class="label-jurusan">
                        PROGRAM KEAHLIAN
                    </span>

                    <h3>Produksi dan Siaran Program Televisi</h3>

                    <p>
                        Mempelajari produksi video, penyiaran,
                        pengambilan gambar, tata suara,
                        dan proses editing.
                    </p>

                    <a
                        href="<?= BASE_URL ?>/jurusan.php"
                        class="link-jurusan"
                    >
                        Lihat Jurusan →
                    </a>

                </div>

            </article>


            <!-- RPL -->
            <article class="kartu-jurusan">

                <div class="foto-jurusan">
                    <img
                        src="<?= BASE_URL ?>/assets/images/rpl.png"
                        alt="Rekayasa Perangkat Lunak"
                    >
                </div>

                <div class="isi-jurusan">

                    <span class="label-jurusan">
                        PROGRAM KEAHLIAN
                    </span>

                    <h3>Rekayasa Perangkat Lunak</h3>

                    <p>
                        Mempelajari pemrograman, pembuatan website,
                        aplikasi, database, dan pengembangan sistem.
                    </p>

                    <a
                        href="<?= BASE_URL ?>/jurusan.php"
                        class="link-jurusan"
                    >
                        Lihat Jurusan →
                    </a>

                </div>

            </article>


            <!-- TKJ -->
            <article class="kartu-jurusan">

                <div class="foto-jurusan">
                    <img
                        src="<?= BASE_URL ?>/assets/images/tkj.png"
                        alt="Teknik Komputer dan Jaringan"
                    >
                </div>

                <div class="isi-jurusan">

                    <span class="label-jurusan">
                        PROGRAM KEAHLIAN
                    </span>

                    <h3>Teknik Komputer dan Jaringan</h3>

                    <p>
                        Mempelajari perakitan komputer, sistem operasi,
                        jaringan komputer, konfigurasi perangkat,
                        dan troubleshooting.
                    </p>

                    <a
                        href="<?= BASE_URL ?>/jurusan.php"
                        class="link-jurusan"
                    >
                        Lihat Jurusan →
                    </a>

                </div>

            </article>

        </div>

    </div>

</section>


<!-- =========================================================
     PROGRAM UNGGULAN
========================================================= -->

<section class="bagian">

    <div class="container">

        <div class="judul-bagian">

            <span class="kop">
                PROGRAM SEKOLAH
            </span>

            <h2>
                Program Unggulan
            </h2>

            <p>
                Kegiatan dan layanan yang mendukung perkembangan
                kompetensi serta karakter peserta didik.
            </p>

        </div>


        <div class="grid-3">


            <article class="kartu">

                <div
                    class="foto"
                    style="display:flex;align-items:center;justify-content:center;font-size:3.5rem;background:var(--kertas-gelap);"
                >
                    🏢
                </div>

                <div class="isi">

                    <h3>
                        Praktik Kerja Lapangan
                    </h3>

                    <p>
                        Memberikan pengalaman kepada siswa
                        melalui praktik langsung di dunia kerja.
                    </p>

                    <a
                        href="<?= BASE_URL ?>/program.php"
                        class="tautan"
                    >
                        Selengkapnya →
                    </a>

                </div>

            </article>


            <article class="kartu">

                <div
                    class="foto"
                    style="display:flex;align-items:center;justify-content:center;font-size:3.5rem;background:var(--kertas-gelap);"
                >
                    💼
                </div>

                <div class="isi">

                    <h3>
                        Bursa Kerja Khusus
                    </h3>

                    <p>
                        Mendukung siswa dan alumni memperoleh
                        informasi serta peluang kerja.
                    </p>

                    <a
                        href="<?= BASE_URL ?>/program.php"
                        class="tautan"
                    >
                        Selengkapnya →
                    </a>

                </div>

            </article>


            <article class="kartu">

                <div
                    class="foto"
                    style="display:flex;align-items:center;justify-content:center;font-size:3.5rem;background:var(--kertas-gelap);"
                >
                    🏆
                </div>

                <div class="isi">

                    <h3>
                        Ekstrakurikuler
                    </h3>

                    <p>
                        Mengembangkan bakat, minat, kreativitas,
                        kepemimpinan, dan kerja sama siswa.
                    </p>

                    <a
                        href="<?= BASE_URL ?>/program.php"
                        class="tautan"
                    >
                        Selengkapnya →
                    </a>

                </div>

            </article>


        </div>

    </div>

</section>


<!-- =========================================================
     BERITA TERBARU
========================================================= -->

<section class="bagian bagian-kertas-gelap">

    <div class="container">

        <div class="judul-bagian">

            <span class="kop">
                INFORMASI TERBARU
            </span>

            <h2>
                Berita Sekolah
            </h2>

            <p>
                Informasi dan kabar terbaru dari sekolah.
            </p>

        </div>


        <?php if (!empty($beritaTerbaru)): ?>

            <div class="grid-3">

                <?php foreach ($beritaTerbaru as $berita): ?>

                    <article class="kartu">

                        <?php if (!empty($berita['foto'])): ?>

                            <div
                                class="foto"
                                style="
                                    background-image:url('<?= BASE_URL ?>/uploads/berita/<?= htmlspecialchars($berita['foto']) ?>');
                                "
                            ></div>

                        <?php else: ?>

                            <div
                                class="foto"
                                style="
                                    display:flex;
                                    align-items:center;
                                    justify-content:center;
                                    font-size:3rem;
                                "
                            >
                                📰
                            </div>

                        <?php endif; ?>


                        <div class="isi">

                            <span class="tanggal">
                                <?= date(
                                    'd M Y',
                                    strtotime($berita['tanggal'])
                                ) ?>
                            </span>

                            <h3>
                                <?= htmlspecialchars($berita['judul']) ?>
                            </h3>

                            <p>

                                <?= htmlspecialchars(
                                    mb_substr(
                                        strip_tags(
                                            $berita['ringkasan']
                                            ?? $berita['isi']
                                        ),
                                        0,
                                        130
                                    )
                                ) ?>

                                ...

                            </p>

                            <a
                                href="<?= BASE_URL ?>/berita_detail.php?slug=<?= urlencode($berita['slug']) ?>"
                                class="tautan"
                            >
                                Baca Selengkapnya →
                            </a>

                        </div>

                    </article>

                <?php endforeach; ?>

            </div>

        <?php else: ?>

            <div class="kotak-info">
                <p>
                    Belum ada berita sekolah.
                </p>
            </div>

        <?php endif; ?>


    </div>

</section>


<!-- =========================================================
     GALERI
========================================================= -->

<section class="bagian">

    <div class="container">

        <div class="judul-bagian">

            <span class="kop">
                KEGIATAN SEKOLAH
            </span>

            <h2>
                Galeri Terbaru
            </h2>

            <p>
                Dokumentasi kegiatan dan aktivitas
                <?= htmlspecialchars($namaSekolah) ?>.
            </p>

        </div>


        <?php if (!empty($galeriTerbaru)): ?>

            <div class="grid-galeri">

                <?php foreach ($galeriTerbaru as $foto): ?>

                    <div
                        class="item-galeri"
                        style="
                            background-image:url('<?= BASE_URL ?>/uploads/galeri/<?= htmlspecialchars($foto['foto']) ?>');
                        "
                    >

                        <div class="keterangan">

                            <?= htmlspecialchars(
                                $foto['judul']
                            ) ?>

                        </div>

                    </div>

                <?php endforeach; ?>

            </div>

        <?php else: ?>

            <div class="kotak-info">

                <p>
                    Belum ada foto galeri.
                </p>

            </div>

        <?php endif; ?>


        <div style="margin-top:28px;">

            <a
                href="<?= BASE_URL ?>/galeri.php"
                class="tombol tombol-utama tombol-kecil"
            >
                Lihat Semua Galeri →
            </a>

        </div>

    </div>

</section>


<!-- =========================================================
     SPMB
========================================================= -->

<section class="hero-s">

    <div class="container">

        <span class="hero-kop">
            PENERIMAAN PESERTA DIDIK BARU
        </span>

        <h1>
            Saatnya Menjadi Bagian dari Kami
        </h1>

        <p class="lead-s">
            Dapatkan informasi jurusan, persyaratan,
            dan alur pendaftaran peserta didik baru.
        </p>

        <div class="hero-aksi">

            <a
                href="<?= BASE_URL ?>/spmb.php"
                class="tombol tombol-utama"
            >
                Lihat Informasi SPMB →
            </a>

            <a
                href="<?= BASE_URL ?>/kontak.php"
                class="tombol tombol-luar"
            >
                Hubungi Sekolah
            </a>

        </div>

    </div>

</section>


<?php require_once __DIR__ . '/includes/web_footer.php'; ?>