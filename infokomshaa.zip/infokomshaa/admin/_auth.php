<?php
require_once __DIR__ . '/../config.php';
if (empty($_SESSION['admin'])) { header('Location: ' . url('admin/login.php')); exit; }
function admin_top($judul, $aktif) {
    $m = ['index' => 'Pendaftar SPMB', 'konten' => 'Jurusan & Gelombang', 'pengaturan' => 'Pengaturan & Logo'];
    ?>
<!DOCTYPE html><html lang="id"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($judul) ?> - Admin</title><link rel="icon" href="<?= logo_url() ?>">
<link rel="stylesheet" href="<?= url('assets/css/style.css') ?>"><link rel="stylesheet" href="<?= url('assets/css/admin.css') ?>"></head>
<body class="adm">
<aside class="side" id="side">
  <div class="side-brand"><img src="<?= logo_url() ?>" alt=""><b><?= e(cfg('nama_sekolah')) ?></b><small>Panel Admin</small></div>
  <?php foreach ($m as $f => $t): ?><a class="rip <?= $aktif === $f ? 'on' : '' ?>" href="<?= url("admin/$f.php") ?>"><?= e($t) ?></a><?php endforeach; ?>
  <a class="rip" href="<?= url('admin/web/dashboard.php') ?>">Konten Website</a>
  <a class="rip" href="<?= url('index.php') ?>" target="_blank">Lihat Website</a>
  <a class="rip out" href="<?= url('admin/logout.php') ?>">Keluar</a>
</aside>
<button class="side-toggle" id="stoggle" aria-label="Menu">&#9776;</button>
<main class="adm-main">
  <h1 class="reveal in"><?= e($judul) ?></h1>
<?php }
function admin_bottom() { ?>
</main>
<div class="toast" id="toast"></div>
<script src="<?= url('assets/js/app.js') ?>"></script>
</body></html>
<?php }
function flash($m = null) {
    if ($m !== null) { $_SESSION['flash'] = $m; return; }
    $f = $_SESSION['flash'] ?? ''; unset($_SESSION['flash']); return $f;
}
