<?php
require_once __DIR__ . '/../config.php';
// Buat akun admin awal bila tabel kosong: admin / admin123
if (!$db->query('SELECT COUNT(*) FROM admin')->fetchColumn()) {
    $db->prepare('INSERT INTO admin (username,password) VALUES (?,?)')->execute(['admin', password_hash('admin123', PASSWORD_DEFAULT)]);
}
if (!empty($_SESSION['admin'])) { header('Location: index.php'); exit; }
$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $s = $db->prepare('SELECT * FROM admin WHERE username=?'); $s->execute([trim($_POST['username'] ?? '')]);
    $a = $s->fetch();
    if (csrf_ok() && $a && password_verify($_POST['password'] ?? '', $a['password'])) {
        session_regenerate_id(true); $_SESSION['admin'] = $a['id']; header('Location: index.php'); exit;
    }
    $err = 'Username atau password salah.';
}
?>
<!DOCTYPE html><html lang="id"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Login Admin</title><link rel="icon" href="<?= logo_url() ?>">
<link rel="stylesheet" href="<?= url('assets/css/style.css') ?>"><link rel="stylesheet" href="<?= url('assets/css/admin.css') ?>"></head>
<body class="login-bg">
<form class="login <?= $err ? 'shake' : '' ?>" method="post">
  <img src="<?= logo_url() ?>" alt="Logo">
  <h2>Login Admin</h2><p><?= e(cfg('nama_sekolah')) ?> <?= e(cfg('kota')) ?></p>
  <?php if ($err): ?><div class="alert"><?= e($err) ?></div><?php endif; ?>
  <?= csrf_field() ?>
  <label>Username<input name="username" autofocus required></label>
  <label>Password<input type="password" name="password" required></label>
  <button class="btn btn-gold rip" type="submit">Masuk</button>
  <a href="<?= url('index.php') ?>" class="back">&larr; Kembali ke website</a>
</form>
<script src="<?= url('assets/js/app.js') ?>"></script>
</body></html>
