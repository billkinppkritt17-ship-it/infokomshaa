<?php
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/includes/unggah_foto.php';
require_once __DIR__ . '/../../includes/fasilitas_db.php';
pastikanTabelFasilitas($koneksi);

$statusPesan = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama      = trim($_POST['nama'] ?? '');
    $ringkasan = trim($_POST['ringkasan'] ?? '');
    $isi       = trim($_POST['isi'] ?? '');
    $urutan    = (int)($_POST['urutan'] ?? 0);

    if (!csrf_ok()) {
        $statusPesan = 'Sesi formulir tidak valid. Muat ulang halaman lalu coba lagi.';
    } elseif ($nama === '' || $isi === '') {
        $statusPesan = 'Nama fasilitas dan deskripsi wajib diisi.';
    } else {
        $hasilUnggah = tanganiUnggahFoto('foto', 'fasilitas');
        if (!$hasilUnggah['sukses']) {
            $statusPesan = $hasilUnggah['pesan'];
        } else {
            $slug = buatSlugFasilitas($koneksi, $nama);
            $stmt = $koneksi->prepare(
                "INSERT INTO fasilitas (nama, slug, ringkasan, isi, foto, urutan) VALUES (?, ?, ?, ?, ?, ?)"
            );
            $stmt->execute([$nama, $slug, $ringkasan ?: null, $isi, $hasilUnggah['namaFile'], $urutan]);
            header('Location: fasilitas.php?status=ditambahkan');
            exit;
        }
    }
}

$urutanBerikut = (int)$koneksi->query("SELECT COALESCE(MAX(urutan),0)+1 FROM fasilitas")->fetchColumn();

$judul_halaman = 'Tambah Fasilitas';
require_once __DIR__ . '/includes/layout_atas.php';
?>

<?php if ($statusPesan): ?>
  <div class="pesan-status pesan-gagal"><?= htmlspecialchars($statusPesan) ?></div>
<?php endif; ?>

<div class="kartu-panel">
  <form method="post" action="fasilitas_tambah.php" enctype="multipart/form-data">
    <?= csrf_field() ?>
    <div class="pratinjau-foto" id="pratinjau"></div>
    <div class="grup-form">
      <label for="foto">Foto Fasilitas</label>
      <input type="file" id="foto" name="foto" accept="image/png,image/jpeg,image/webp" onchange="pratinjauGambar(this,'pratinjau')">
      <p class="bantuan-form">Opsional. Format JPG/PNG/WEBP, maksimal 3MB.</p>
    </div>
    <div class="grup-form">
      <label for="nama">Nama Fasilitas</label>
      <input type="text" id="nama" name="nama" placeholder="Contoh: Laboratorium Komputer" value="<?= htmlspecialchars($_POST['nama'] ?? '') ?>" required>
    </div>
    <div class="grup-form">
      <label for="ringkasan">Ringkasan Singkat</label>
      <input type="text" id="ringkasan" name="ringkasan" placeholder="Tampil di daftar fasilitas, maks 1-2 kalimat" value="<?= htmlspecialchars($_POST['ringkasan'] ?? '') ?>">
    </div>
    <div class="grup-form">
      <label for="isi">Deskripsi Lengkap</label>
      <textarea id="isi" name="isi" style="min-height:220px;" placeholder="Jelaskan fasilitas ini: kelengkapan, jumlah, kegunaan, dst." required><?= htmlspecialchars($_POST['isi'] ?? '') ?></textarea>
    </div>
    <div class="grup-form">
      <label for="urutan">Urutan Tampil</label>
      <input type="number" id="urutan" name="urutan" value="<?= (int)($_POST['urutan'] ?? $urutanBerikut) ?>">
      <p class="bantuan-form">Angka kecil tampil lebih dulu di website.</p>
    </div>
    <button type="submit" class="tombol">Simpan</button>
    <a href="fasilitas.php" class="tombol tombol-garis">Batal</a>
  </form>
</div>

<script>
function pratinjauGambar(input, targetId) {
  if (!input.files || !input.files[0]) return;
  var reader = new FileReader();
  reader.onload = function (e) {
    document.getElementById(targetId).style.backgroundImage = 'url(' + e.target.result + ')';
  };
  reader.readAsDataURL(input.files[0]);
}
</script>

<?php require_once __DIR__ . '/includes/layout_bawah.php'; ?>
