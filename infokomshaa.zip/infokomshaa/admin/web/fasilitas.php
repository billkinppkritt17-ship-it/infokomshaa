<?php
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/../../includes/fasilitas_db.php';
pastikanTabelFasilitas($koneksi);

$daftarFasilitas = $koneksi->query("SELECT * FROM fasilitas ORDER BY urutan ASC, id ASC")->fetchAll();

$judul_halaman = 'Fasilitas';
require_once __DIR__ . '/includes/layout_atas.php';
?>

<?php if (!empty($_GET['status'])): ?>
  <div class="pesan-status pesan-berhasil">
    <?= $_GET['status'] === 'ditambahkan' ? 'Fasilitas berhasil ditambahkan.' :
        ($_GET['status'] === 'diubah' ? 'Fasilitas berhasil diperbarui.' : 'Fasilitas berhasil dihapus.') ?>
  </div>
<?php endif; ?>

<div class="baris-header-panel">
  <h3 style="margin:0;">Daftar Fasilitas</h3>
  <a href="fasilitas_tambah.php" class="tombol">+ Tambah Fasilitas</a>
</div>

<div class="kartu-panel">
  <?php if ($daftarFasilitas): ?>
  <table class="tabel-admin">
    <thead><tr><th>Foto</th><th>Nama Fasilitas</th><th>Urutan</th><th>Aksi</th></tr></thead>
    <tbody>
      <?php foreach ($daftarFasilitas as $f): ?>
      <tr>
        <td><img class="mini-foto" src="<?= $f['foto'] ? '../../uploads/fasilitas/'.htmlspecialchars($f['foto']) : 'https://placehold.co/48x48/EDE6D6/1C2B39?text=F' ?>" alt=""></td>
        <td><?= htmlspecialchars($f['nama']) ?></td>
        <td><?= (int)$f['urutan'] ?></td>
        <td>
          <a class="tombol tombol-garis tombol-kecil" href="fasilitas_edit.php?id=<?= $f['id'] ?>">Edit</a>
          <form method="post" action="fasilitas_hapus.php" style="display:inline;" onsubmit="return confirm('Yakin ingin menghapus fasilitas ini? Tindakan ini tidak bisa dibatalkan.');">
            <?= csrf_field() ?>
            <input type="hidden" name="id" value="<?= $f['id'] ?>">
            <button type="submit" class="tombol tombol-bahaya tombol-kecil">Hapus</button>
          </form>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
  <?php else: ?>
    <p style="color:var(--teks-muda);">Belum ada fasilitas. Klik "Tambah Fasilitas" untuk membuat yang pertama.</p>
  <?php endif; ?>
</div>

<?php require_once __DIR__ . '/includes/layout_bawah.php'; ?>
