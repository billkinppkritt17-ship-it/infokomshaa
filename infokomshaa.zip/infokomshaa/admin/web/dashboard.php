<?php
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/../../includes/fasilitas_db.php';
pastikanTabelFasilitas($koneksi);

$jumlahGuru   = $koneksi->query("SELECT COUNT(*) FROM guru")->fetchColumn();
$jumlahGaleri = $koneksi->query("SELECT COUNT(*) FROM galeri")->fetchColumn();
$jumlahBerita = $koneksi->query("SELECT COUNT(*) FROM berita")->fetchColumn();
$jumlahFasilitas = $koneksi->query("SELECT COUNT(*) FROM fasilitas")->fetchColumn();
$jumlahPesan  = $koneksi->query("SELECT COUNT(*) FROM pesan WHERE sudah_dibaca = 0")->fetchColumn();

$pesanTerbaru = $koneksi->query("SELECT * FROM pesan ORDER BY dikirim_pada DESC LIMIT 5")->fetchAll();

$judul_halaman = 'Dasbor';
require_once __DIR__ . '/includes/layout_atas.php';
?>

<p style="color:var(--teks-muda);margin-top:0;">Selamat datang kembali, <strong><?= htmlspecialchars($_SESSION['admin_nama']) ?></strong>.</p>

<div class="grid-statistik">
  <div class="kotak-statistik">
    <span class="angka"><?= (int)$jumlahGuru ?></span>
    <span class="label">Guru & Staf</span>
  </div>
  <div class="kotak-statistik">
    <span class="angka"><?= (int)$jumlahGaleri ?></span>
    <span class="label">Foto Galeri</span>
  </div>
  <div class="kotak-statistik">
    <span class="angka"><?= (int)$jumlahBerita ?></span>
    <span class="label">Berita Terbit</span>
  </div>
  <div class="kotak-statistik">
    <span class="angka"><?= (int)$jumlahFasilitas ?></span>
    <span class="label">Fasilitas</span>
  </div>
  <div class="kotak-statistik">
    <span class="angka"><?= (int)$jumlahPesan ?></span>
    <span class="label">Pesan Belum Dibaca</span>
  </div>
</div>

<div class="kartu-panel">
  <div class="baris-header-panel">
    <h3 style="margin:0;">Pesan Masuk Terbaru</h3>
    <a href="pesan.php" class="tombol tombol-garis tombol-kecil">Lihat Semua</a>
  </div>
  <?php if ($pesanTerbaru): ?>
  <table class="tabel-admin">
    <thead><tr><th>Nama</th><th>Subjek</th><th>Tanggal</th><th>Status</th></tr></thead>
    <tbody>
      <?php foreach ($pesanTerbaru as $p): ?>
      <tr>
        <td><?= htmlspecialchars($p['nama']) ?></td>
        <td><?= htmlspecialchars($p['subjek'] ?: '(tanpa subjek)') ?></td>
        <td><?= date('d M Y H:i', strtotime($p['dikirim_pada'])) ?></td>
        <td><?= $p['sudah_dibaca'] ? '<span class="lencana">Dibaca</span>' : '<span class="lencana" style="background:#FBEED9;color:#8A5A16;">Baru</span>' ?></td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
  <?php else: ?>
    <p style="color:var(--teks-muda);">Belum ada pesan masuk.</p>
  <?php endif; ?>
</div>

<?php require_once __DIR__ . '/includes/layout_bawah.php'; ?>
