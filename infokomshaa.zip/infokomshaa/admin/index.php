<?php
require_once __DIR__ . '/_auth.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && csrf_ok() && isset($_POST['hapus'])) {
    $db->prepare('DELETE FROM pendaftar WHERE id=?')->execute([(int)$_POST['hapus']]);
    flash('Data pendaftar dihapus.'); header('Location: index.php'); exit;
}
$q = trim($_GET['q'] ?? ''); $fj = (int)($_GET['j'] ?? 0);
$where = '1'; $par = [];
if ($q !== '') { $where .= ' AND (p.nama LIKE ? OR p.no_daftar LIKE ? OR p.asal_sekolah LIKE ?)'; array_push($par, "%$q%", "%$q%", "%$q%"); }
if ($fj) { $where .= ' AND p.jurusan_id=?'; $par[] = $fj; }
$sql = "SELECT p.*, j.singkatan AS js, g.nama AS gn FROM pendaftar p LEFT JOIN jurusan j ON j.id=p.jurusan_id LEFT JOIN gelombang g ON g.id=p.gelombang_id WHERE $where ORDER BY p.id DESC";
$st = $db->prepare($sql); $st->execute($par); $rows = $st->fetchAll();

if (isset($_GET['csv'])) {
    header('Content-Type: text/csv; charset=utf-8'); header('Content-Disposition: attachment; filename="pendaftar-spmb.csv"');
    $o = fopen('php://output', 'w'); fwrite($o, "\xEF\xBB\xBF");
    fputcsv($o, ['No Daftar','Nama','NISN','TTL','JK','Asal Sekolah','Jurusan','Gelombang','Orang Tua','HP Ortu','HP','Email','Alamat','Tanggal Daftar']);
    foreach ($rows as $r) fputcsv($o, [$r['no_daftar'],$r['nama'],$r['nisn'],$r['tempat_lahir'].', '.$r['tanggal_lahir'],$r['jk'],$r['asal_sekolah'],$r['js'],$r['gn'],$r['nama_ortu'],$r['hp_ortu'],$r['hp'],$r['email'],$r['alamat'],$r['created_at']]);
    exit;
}
$total = (int)$db->query('SELECT COUNT(*) FROM pendaftar')->fetchColumn();
$perJ = $db->query('SELECT j.id,j.singkatan,COUNT(p.id) c FROM jurusan j LEFT JOIN pendaftar p ON p.jurusan_id=j.id GROUP BY j.id ORDER BY j.urutan')->fetchAll();
$jurAll = $db->query('SELECT id,singkatan FROM jurusan ORDER BY urutan')->fetchAll();
$hariIni = (int)$db->query('SELECT COUNT(*) FROM pendaftar WHERE DATE(created_at)=CURDATE()')->fetchColumn();

admin_top('Dashboard', 'index');
if ($f = flash()) echo '<div class="notice">' . e($f) . '</div>';
?>
<div class="stats">
  <div class="stat rip reveal in"><small>Total Pendaftar</small><b data-count="<?= $total ?>">0</b></div>
  <div class="stat rip reveal in"><small>Hari Ini</small><b data-count="<?= $hariIni ?>">0</b></div>
  <?php foreach ($perJ as $p): ?><div class="stat rip reveal in"><small><?= e($p['singkatan']) ?></small><b data-count="<?= (int)$p['c'] ?>">0</b></div><?php endforeach; ?>
</div>

<form class="filter" method="get">
  <input name="q" placeholder="Cari nama / no. daftar / asal sekolah" value="<?= e($q) ?>">
  <select name="j"><option value="0">Semua jurusan</option><?php foreach ($jurAll as $j): ?><option value="<?= $j['id'] ?>" <?= $fj === (int)$j['id'] ? 'selected' : '' ?>><?= e($j['singkatan']) ?></option><?php endforeach; ?></select>
  <button class="btn btn-blue rip">Cari</button>
  <a class="btn btn-ghost-dark rip" href="?csv=1&q=<?= urlencode($q) ?>&j=<?= $fj ?>">Ekspor CSV</a>
</form>

<div class="tbl-wrap"><table>
  <thead><tr><th>No. Daftar</th><th>Nama</th><th>Asal Sekolah</th><th>Jurusan</th><th>Gelombang</th><th>HP Ortu</th><th>Tanggal</th><th>Aksi</th></tr></thead>
  <tbody>
  <?php foreach ($rows as $r): ?>
    <tr>
      <td><?= e($r['no_daftar']) ?></td><td><b><?= e($r['nama']) ?></b><br><small><?= $r['jk'] === 'L' ? 'Laki-laki' : 'Perempuan' ?></small></td>
      <td><?= e($r['asal_sekolah']) ?></td><td><span class="tag"><?= e($r['js']) ?></span></td><td><?= e($r['gn']) ?></td>
      <td><?= e($r['hp_ortu']) ?></td><td><?= date('d/m/Y H:i', strtotime($r['created_at'])) ?></td>
      <td class="act">
        <a class="mini rip" href="<?= url('formulir_pdf.php?id=' . $r['id']) ?>">PDF</a>
        <form method="post" data-confirm="Hapus data <?= e($r['nama']) ?>?"><?= csrf_field() ?><button class="mini red rip" name="hapus" value="<?= $r['id'] ?>">Hapus</button></form>
      </td>
    </tr>
  <?php endforeach; if (!$rows) echo '<tr><td colspan="8" class="empty">Belum ada data pendaftar.</td></tr>'; ?>
  </tbody>
</table></div>
<?php admin_bottom(); ?>
