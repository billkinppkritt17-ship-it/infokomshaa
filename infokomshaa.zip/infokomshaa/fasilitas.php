<?php

require_once __DIR__ . '/config/koneksi.php';
require_once __DIR__ . '/includes/fasilitas_db.php';
pastikanTabelFasilitas($koneksi);

$judul_halaman = 'Fasilitas';

$semuaFasilitas = $koneksi->query("
    SELECT *
    FROM fasilitas
    ORDER BY urutan ASC, id ASC
")->fetchAll();

?>

<?php require_once __DIR__ . '/includes/web_header.php'; ?>

<section class="header-halaman">
    <div class="container">
        <h1>Fasilitas Sekolah</h1>
        <p>Sarana dan prasarana yang mendukung kegiatan belajar di sekolah.</p>
    </div>
</section>

<section class="bagian">
    <div class="container">

        <div class="judul-bagian">
            <span class="kop">SARANA &amp; PRASARANA</span>
            <h2>Fasilitas Kami</h2>
            <p>
                Kenali fasilitas yang tersedia untuk menunjang pembelajaran
                dan kegiatan siswa.
            </p>
        </div>

        <?php if (!empty($semuaFasilitas)): ?>

            <div class="grid-3">

                <?php foreach ($semuaFasilitas as $f): ?>

                    <a
                        href="<?= BASE_URL ?>/fasilitas_detail.php?slug=<?= urlencode($f['slug']) ?>"
                        class="kartu"
                    >

                        <?php if (!empty($f['foto'])): ?>

                            <div
                                class="foto"
                                style="background-image:url('<?= BASE_URL ?>/uploads/fasilitas/<?= htmlspecialchars($f['foto']) ?>');"
                            ></div>

                        <?php else: ?>

                            <div
                                class="foto"
                                style="display:flex;align-items:center;justify-content:center;background:var(--papan);color:var(--kertas);font-family:var(--font-judul);font-size:2rem;"
                            >
                                FASILITAS
                            </div>

                        <?php endif; ?>

                        <div class="isi">

                            <h3>
                                <?= htmlspecialchars($f['nama']) ?>
                            </h3>

                            <p>
                                <?= htmlspecialchars(
                                    $f['ringkasan']
                                    ?: mb_strimwidth(
                                        strip_tags($f['isi']),
                                        0,
                                        110,
                                        '...'
                                    )
                                ) ?>
                            </p>

                            <span class="tautan">
                                Lihat selengkapnya &rarr;
                            </span>

                        </div>

                    </a>

                <?php endforeach; ?>

            </div>

        <?php else: ?>

            <div class="kotak-info">
                <h3>Belum Ada Fasilitas</h3>
                <p>
                    Informasi fasilitas sekolah belum ditambahkan.
                    Silakan tambahkan melalui panel admin.
                </p>
            </div>

        <?php endif; ?>

    </div>
</section>

<section class="bagian bagian-kertas-gelap">
    <div class="container">

        <div class="judul-bagian">
            <span class="kop">INGIN TAHU LEBIH BANYAK?</span>

            <h2>Kunjungi atau Hubungi Sekolah</h2>

            <p>
                Hubungi sekolah jika membutuhkan informasi lebih lanjut
                mengenai fasilitas dan layanan.
            </p>

            <a
                href="<?= BASE_URL ?>/kontak.php"
                class="tombol tombol-utama"
            >
                Hubungi Sekolah →
            </a>
        </div>

    </div>
</section>

<?php require_once __DIR__ . '/includes/web_footer.php'; ?>
