<?php
/** Penutup halaman sekolah: animasi SPMB + footer SPMB. */
?>
<script>
  // Samakan efek dengan halaman SPMB (muncul saat scroll + riak saat klik)
  document.querySelectorAll('.judul-bagian,.statistik,.grid-2,.grid-3,.grid-jurusan,.grid-galeri,.grid-alumni-jepang,.formulir,.isi-artikel')
    .forEach(function (el) { el.classList.add('reveal'); });
  document.querySelectorAll('.tombol').forEach(function (el) { el.classList.add('rip'); });
</script>
<?php $extra_js = [url('assets/js/sekolah.js'), url('assets/js/animasi.js')]; require __DIR__ . '/footer.php'; ?>
