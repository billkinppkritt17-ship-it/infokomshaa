<?php
/**
 * Pembuka halaman sekolah (Beranda, Profil, dst).
 * Memakai header/navbar SPMB yang sama (includes/header.php) + sekolah.css.
 * Variabel opsional sebelum include: $judul_halaman
 */
if (!isset($koneksi)) {
    require_once __DIR__ . '/../config/koneksi.php';
}
$profil = $koneksi->query("SELECT * FROM profil_sekolah LIMIT 1")->fetch() ?: [];
$namaSekolah = $profil['nama_sekolah'] ?? cfg('nama_sekolah');
$halamanSaatIni = basename($_SERVER['SCRIPT_NAME']);
$judul = ($judul_halaman ?? 'Beranda') . ' — ' . $namaSekolah;
$extra_css = [url('assets/css/sekolah.css'), url('assets/css/animasi.css')];
require __DIR__ . '/header.php';
