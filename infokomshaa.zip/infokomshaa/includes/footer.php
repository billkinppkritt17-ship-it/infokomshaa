<footer class="foot">
  <div class="foot-in">
    <img src="<?= logo_url() ?>" alt="">
    <div>
      <b><?= e(cfg('nama_sekolah')) ?> <?= e(cfg('kota')) ?></b>
      <p><?= e(cfg('yayasan')) ?> &middot; Terakreditasi &ldquo;<?= e(cfg('akreditasi')) ?>&rdquo;</p>
      <p><?= e(cfg('alamat')) ?></p>
    </div>
    <nav class="foot-links">
      <a href="<?= url('profil.php') ?>">Profil</a><a href="<?= url('jurusan.php') ?>">Jurusan</a><a href="<?= url('program.php') ?>">Program</a><a href="<?= url('fasilitas.php') ?>">Fasilitas</a>
      <a href="<?= url('guru.php') ?>">Guru &amp; Staf</a><a href="<?= url('galeri.php') ?>">Galeri</a><a href="<?= url('berita.php') ?>">Berita</a>
      <a href="<?= url('kontak.php') ?>">Kontak</a><a href="<?= url('spmb.php') ?>">SPMB</a>
    </nav>
    <a class="foot-admin" href="<?= url('admin/login.php') ?>">Login Admin</a>
  </div>
  <div class="copy">&copy; <?= date('Y') ?> <?= e(cfg('nama_sekolah')) ?>. SPMB TA <?= e(cfg('tahun_ajaran')) ?>.</div>
</footer>
<div class="toast" id="toast"></div>
<script src="<?= url('assets/js/app.js') ?>"></script>
<?php foreach (($extra_js ?? []) as $_j): ?><script src="<?= e($_j) ?>"></script>
<?php endforeach; ?>
</body>
</html>
