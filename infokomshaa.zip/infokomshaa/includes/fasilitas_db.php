<?php
/**
 * Pembantu fitur Fasilitas.
 * - pastikanTabelFasilitas(): membuat tabel `fasilitas` otomatis bila belum ada,
 *   jadi Anda TIDAK perlu import ulang database setelah menambah fitur ini.
 * - buatSlugFasilitas(): membuat alamat URL unik dari nama fasilitas.
 */
function pastikanTabelFasilitas(PDO $db): void
{
    static $sudah = false;
    if ($sudah) return;

    $db->exec("CREATE TABLE IF NOT EXISTS fasilitas (
        id INT AUTO_INCREMENT PRIMARY KEY,
        nama VARCHAR(150) NOT NULL,
        slug VARCHAR(180) NOT NULL UNIQUE,
        ringkasan VARCHAR(255) DEFAULT NULL,
        isi TEXT NOT NULL,
        foto VARCHAR(255) DEFAULT NULL,
        urutan INT NOT NULL DEFAULT 0,
        dibuat_pada TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");

    $sudah = true;
}

function buatSlugFasilitas(PDO $db, string $nama, ?int $idKecuali = null): string
{
    $dasar = strtolower(trim($nama));
    $dasar = preg_replace('/[^a-z0-9]+/', '-', $dasar);
    $dasar = trim($dasar, '-');
    if ($dasar === '') $dasar = 'fasilitas';

    $slug = $dasar;
    $angka = 1;
    while (true) {
        $sql = "SELECT COUNT(*) FROM fasilitas WHERE slug = ?" . ($idKecuali ? " AND id != ?" : "");
        $stmt = $db->prepare($sql);
        $stmt->execute($idKecuali ? [$slug, $idKecuali] : [$slug]);
        if ((int)$stmt->fetchColumn() === 0) return $slug;
        $angka++;
        $slug = $dasar . '-' . $angka;
    }
}
