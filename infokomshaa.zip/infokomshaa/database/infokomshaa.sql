CREATE DATABASE IF NOT EXISTS db_infokomshaa CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE db_infokomshaa;

CREATE TABLE IF NOT EXISTS admin (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL
);

CREATE TABLE IF NOT EXISTS pengaturan (
  kunci VARCHAR(50) PRIMARY KEY,
  nilai TEXT
);

CREATE TABLE IF NOT EXISTS jurusan (
  id INT AUTO_INCREMENT PRIMARY KEY,
  bidang VARCHAR(100) NOT NULL,
  nama VARCHAR(150) NOT NULL,
  singkatan VARCHAR(20) NOT NULL,
  deskripsi TEXT,
  gambar VARCHAR(255),
  urutan INT DEFAULT 0
);

CREATE TABLE IF NOT EXISTS gelombang (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nama VARCHAR(50) NOT NULL,
  tanggal VARCHAR(100) NOT NULL,
  bonus VARCHAR(200) NOT NULL,
  urutan INT DEFAULT 0
);

CREATE TABLE IF NOT EXISTS pendaftar (
  id INT AUTO_INCREMENT PRIMARY KEY,
  no_daftar VARCHAR(20) UNIQUE,
  nama VARCHAR(100) NOT NULL,
  nisn VARCHAR(20),
  tempat_lahir VARCHAR(60),
  tanggal_lahir DATE,
  jk ENUM('L','P') NOT NULL,
  asal_sekolah VARCHAR(100),
  alamat TEXT,
  jurusan_id INT,
  gelombang_id INT,
  nama_ortu VARCHAR(100),
  hp_ortu VARCHAR(20),
  hp VARCHAR(20),
  email VARCHAR(100),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO pengaturan (kunci, nilai) VALUES
('nama_sekolah','SMK INFOKOM'),
('kota','Kota Bogor'),
('yayasan','Yayasan Telekomunikasi Nasional'),
('akreditasi','A'),
('tahun_ajaran','2026-2027'),
('telepon','0878-7307-1400'),
('instagram','smk.infokom_official'),
('website','www.smkinfokom-bogor.sch.id'),
('alamat','Jl. Letjend Ibrahim Adjie No. 178, Kota Bogor'),
('jam','Senin s/d Sabtu | 08.00-15.00 WIB'),
('logo','assets/images/logo-sekolah.png'),
('logo_v','1')
ON DUPLICATE KEY UPDATE kunci=kunci;

INSERT INTO jurusan (bidang,nama,singkatan,deskripsi,gambar,urutan) VALUES
('Teknologi Informasi','Teknik Komputer dan Jaringan','TKJ','Belajar merakit dan merawat komputer, membangun jaringan, administrasi server, dan keamanan jaringan.','assets/images/tkj.png',1),
('Teknologi Informasi','Rekayasa Perangkat Lunak','RPL','Belajar membuat aplikasi web, mobile, dan desktop mulai dari analisis kebutuhan, pemrograman, hingga basis data.','assets/images/rpl.png',2),
('Seni dan Ekonomi Kreatif','Desain Komunikasi Visual','DKV','Belajar desain grafis, ilustrasi, fotografi, animasi, dan branding untuk kebutuhan industri kreatif.','assets/images/dkv.png',3),
('Seni dan Ekonomi Kreatif','Produksi dan Siaran Program Televisi','PSPT','Belajar produksi video, penyutradaraan, kamera, editing, dan siaran program televisi.','assets/images/pspt.png',4);

INSERT INTO gelombang (nama,tanggal,bonus,urutan) VALUES
('Gelombang 1','15 Desember 2025 - 30 April 2026','Free 1 Unit Laptop',1),
('Gelombang 2','1 Mei - 30 Juni 2026','Free SPP 3 Bulan',2),
('Gelombang 3','1 Juli - 30 Agustus 2026','Free Seragam (Jas Almamater, Olahraga & Jurusan)',3);


-- =========================================================
-- HALAMAN SEKOLAH: Beranda, Profil, Jurusan, Program,
-- Guru & Staf, Berita, Galeri, Kontak (dari sekolah-website-kum)
-- =========================================================

CREATE TABLE IF NOT EXISTS profil_sekolah (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nama_sekolah VARCHAR(150) NOT NULL,
  npsn VARCHAR(50) DEFAULT NULL,
  alamat TEXT,
  telepon VARCHAR(50),
  email VARCHAR(100),
  jam_operasional VARCHAR(150),
  sejarah TEXT,
  visi TEXT,
  misi TEXT,
  logo VARCHAR(255) DEFAULT NULL,
  foto_gedung VARCHAR(255) DEFAULT NULL,
  peta_embed TEXT
);

INSERT INTO profil_sekolah (nama_sekolah, npsn, alamat, telepon, email, jam_operasional, sejarah, visi, misi)
SELECT 'SMK Infokom', NULL,
  'Jl. Letjend Ibrahim Adjie No. 178, Kota Bogor, Jawa Barat',
  '0878-7307-1400', '',
  'Senin s/d Sabtu | 08.00-15.00 WIB',
  'SMK Infokom Kota Bogor dikelola oleh Yayasan Telekomunikasi Nasional dan membuka empat kompetensi keahlian: Teknik Komputer dan Jaringan, Rekayasa Perangkat Lunak, Desain Komunikasi Visual, serta Produksi dan Siaran Program Televisi. Ubah teks sejarah ini melalui menu Profil Sekolah di panel admin.',
  'Menjadi lembaga pendidikan kejuruan yang unggul dalam prestasi, berkarakter, dan siap kerja di bidang teknologi informasi dan industri kreatif.',
  '1. Menyelenggarakan pembelajaran yang aktif, kreatif, dan menyenangkan.\n2. Membina akhlak mulia dan disiplin siswa.\n3. Mengembangkan potensi siswa melalui kegiatan ekstrakurikuler.\n4. Menjalin kerja sama dengan orang tua, industri, dan masyarakat.'
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM profil_sekolah);

CREATE TABLE IF NOT EXISTS guru (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nama VARCHAR(100) NOT NULL,
  nip VARCHAR(50) DEFAULT NULL,
  jabatan VARCHAR(100) NOT NULL,
  mata_pelajaran VARCHAR(100) DEFAULT NULL,
  foto VARCHAR(255) DEFAULT NULL,
  dibuat_pada TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO guru (nama, nip, jabatan, mata_pelajaran, foto)
SELECT * FROM (
  SELECT 'Dra. Sri Wahyuni, M.Pd.' AS nama, '196705121990032001' AS nip, 'Kepala Sekolah' AS jabatan, NULL AS mata_pelajaran, NULL AS foto
  UNION ALL SELECT 'Budi Santoso, S.Pd.', '197803242005011002', 'Wakil Kepala Sekolah', 'Matematika', NULL
  UNION ALL SELECT 'Rina Marlina, S.Pd.', '198207152009022003', 'Guru', 'Bahasa Indonesia', NULL
) t WHERE NOT EXISTS (SELECT 1 FROM guru);

CREATE TABLE IF NOT EXISTS galeri (
  id INT AUTO_INCREMENT PRIMARY KEY,
  judul VARCHAR(150) NOT NULL,
  deskripsi TEXT,
  foto VARCHAR(255) NOT NULL,
  tanggal DATE DEFAULT NULL,
  dibuat_pada TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS berita (
  id INT AUTO_INCREMENT PRIMARY KEY,
  judul VARCHAR(200) NOT NULL,
  slug VARCHAR(220) NOT NULL UNIQUE,
  ringkasan VARCHAR(255) DEFAULT NULL,
  isi TEXT NOT NULL,
  foto VARCHAR(255) DEFAULT NULL,
  penulis VARCHAR(100) DEFAULT 'Admin',
  tanggal TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO berita (judul, slug, ringkasan, isi, penulis) VALUES
('Pendaftaran Murid Baru (SPMB) Tahun Ajaran 2026-2027',
 'spmb-2026-2027',
 'Pendaftaran murid baru dibuka, simak jadwal gelombang dan bonusnya.',
 'SMK Infokom membuka Sistem Penerimaan Murid Baru (SPMB) tahun ajaran 2026-2027. Calon murid dapat mendaftar secara daring melalui halaman SPMB di website ini. Informasi lebih lanjut dapat menghubungi bagian tata usaha.',
 'Admin')
ON DUPLICATE KEY UPDATE slug=slug;

CREATE TABLE IF NOT EXISTS pesan (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nama VARCHAR(100) NOT NULL,
  email VARCHAR(100) NOT NULL,
  subjek VARCHAR(150) DEFAULT NULL,
  isi_pesan TEXT NOT NULL,
  sudah_dibaca TINYINT(1) DEFAULT 0,
  dikirim_pada TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS program_sekolah (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nomor VARCHAR(10) DEFAULT NULL,
  ikon VARCHAR(50) DEFAULT NULL,
  judul VARCHAR(150) NOT NULL,
  singkatan VARCHAR(50) DEFAULT NULL,
  deskripsi TEXT DEFAULT NULL,
  foto VARCHAR(255) DEFAULT NULL,
  urutan INT DEFAULT 0,
  aktif TINYINT(1) DEFAULT 1,
  dibuat_pada TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS alumni_jepang (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nama VARCHAR(150) NOT NULL,
  jurusan VARCHAR(100) DEFAULT NULL,
  tahun_lulus VARCHAR(10) DEFAULT NULL,
  tahun_berangkat VARCHAR(10) DEFAULT NULL,
  perusahaan VARCHAR(150) DEFAULT NULL,
  foto VARCHAR(255) DEFAULT NULL,
  dibuat_pada TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS fasilitas (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nama VARCHAR(150) NOT NULL,
  slug VARCHAR(180) NOT NULL UNIQUE,
  ringkasan VARCHAR(255) DEFAULT NULL,
  isi TEXT NOT NULL,
  foto VARCHAR(255) DEFAULT NULL,
  urutan INT NOT NULL DEFAULT 0,
  dibuat_pada TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
