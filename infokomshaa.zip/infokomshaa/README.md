# infokomshaa - Website SMK INFOKOM Kota Bogor (Profil Sekolah + SPMB)

PHP native (PDO) + MySQL (XAMPP). Fitur: halaman SPMB bertema poster, animasi klik, formulir pendaftaran online,
unduh formulir PDF (kosong / terisi), panel admin, ganti logo, kelola jurusan & gelombang.

## Halaman
Beranda `index.php`, Profil `profil.php`, Jurusan `jurusan.php`, Program `program.php`, Guru & Staf `guru.php`,
Berita `berita.php`, Fasilitas `fasilitas.php`, Galeri `galeri.php`, Kontak `kontak.php`, dan SPMB `spmb.php` (+ `daftar.php`).
Konten Beranda/Profil/Guru/Berita/Fasilitas/Galeri/Program/Pesan dikelola di **Admin -> Konten Website** (`admin/web/dashboard.php`);
data pendaftar SPMB di `admin/index.php`. Login admin satu untuk semua.

## Instalasi (XAMPP)
1. Ekstrak ZIP, salin folder `infokomshaa` ke `C:\xampp\htdocs\infokomshaa`
2. Buka XAMPP Control Panel -> Start **Apache** dan **MySQL**
3. Buka http://localhost/phpmyadmin -> tab **Import** -> pilih `database/infokomshaa.sql` -> **Import**
   (database `db_infokomshaa` otomatis dibuat)
4. Buka website: http://localhost/infokomshaa/
5. Buka admin: http://localhost/infokomshaa/admin/login.php
   Login awal: **admin / admin123** (segera ganti di menu Pengaturan & Logo)

Jika password MySQL root Anda tidak kosong, ubah `$db_pass` di `config.php`.
Pastikan ekstensi `gd`, `fileinfo`, dan `iconv` aktif (default XAMPP sudah aktif).

## Fasilitas (baru)
Menu **Admin -> Konten Website -> Fasilitas** (`admin/web/fasilitas.php`): tambah, edit, hapus fasilitas lengkap dengan foto, ringkasan,
deskripsi, dan urutan tampil. Tampil di website pada `fasilitas.php` (daftar) dan `fasilitas_detail.php` (rincian).
Tabel `fasilitas` dibuat otomatis saat menu dibuka, tidak perlu import ulang database.
