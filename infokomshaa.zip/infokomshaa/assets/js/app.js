(function () {
  const $ = (s, c = document) => c.querySelector(s);
  const $$ = (s, c = document) => [...c.querySelectorAll(s)];

  // 1. Animasi ripple saat elemen diklik
  document.addEventListener('click', function (e) {
    const el = e.target.closest('.rip');
    if (!el) return;
    const r = el.getBoundingClientRect(), d = Math.max(r.width, r.height);
    const s = document.createElement('span');
    s.className = 'ripple';
    s.style.cssText = `width:${d}px;height:${d}px;left:${e.clientX - r.left - d / 2}px;top:${e.clientY - r.top - d / 2}px`;
    el.appendChild(s);
    setTimeout(() => s.remove(), 700);
    if (el.classList.contains('card') || el.classList.contains('info') || el.classList.contains('stat')) {
      el.classList.remove('pop'); void el.offsetWidth; el.classList.add('pop');
    }
  });

  // 2. Navbar: efek scroll + menu mobile
  const nav = $('#nav'), burger = $('#burger'), menu = $('#menu');
  if (nav) addEventListener('scroll', () => nav.classList.toggle('sc', scrollY > 30), { passive: true });
  if (burger) {
    burger.addEventListener('click', () => { burger.classList.toggle('open'); menu.classList.toggle('open'); });
    $$('#menu a').forEach(a => a.addEventListener('click', () => { burger.classList.remove('open'); menu.classList.remove('open'); }));
  }

  // 3. Animasi muncul saat di-scroll
  const io = 'IntersectionObserver' in window ? new IntersectionObserver(es => es.forEach(en => {
    if (en.isIntersecting) { en.target.classList.add('in'); io.unobserve(en.target); }
  }), { threshold: .12 }) : null;
  $$('.reveal').forEach((el, i) => { el.style.transitionDelay = (i % 4) * 90 + 'ms'; io ? io.observe(el) : el.classList.add('in'); });

  // 4. Modal detail jurusan
  const modal = $('#modal');
  if (modal) {
    const close = () => { modal.classList.remove('show'); modal.setAttribute('aria-hidden', 'true'); };
    const open = c => {
      $('#m-img').src = c.dataset.img; $('#m-s').textContent = c.dataset.singkat;
      $('#m-n').textContent = c.dataset.nama; $('#m-d').textContent = c.dataset.desc;
      $('#m-go').href = $('#m-go').href.split('?')[0] + '?j=' + c.dataset.id;
      modal.classList.add('show'); modal.setAttribute('aria-hidden', 'false');
    };
    $$('.jcard').forEach(c => { c.addEventListener('click', () => open(c)); c.addEventListener('keydown', e => e.key === 'Enter' && open(c)); });
    $('#mx').addEventListener('click', close);
    modal.addEventListener('click', e => e.target === modal && close());
    addEventListener('keydown', e => e.key === 'Escape' && close());
  }

  // 5. Kartu gelombang: klik untuk menampilkan tombol daftar
  $$('.gcard').forEach(c => {
    const toggle = () => { const was = c.classList.contains('sel'); $$('.gcard').forEach(x => x.classList.remove('sel')); if (!was) c.classList.add('sel'); };
    c.addEventListener('click', e => { if (!e.target.closest('.go')) toggle(); });
    c.addEventListener('keydown', e => e.key === 'Enter' && toggle());
  });

  // 6. Form daftar: animasi loading + cek isian
  const f = $('#fdaftar');
  if (f) f.addEventListener('submit', e => {
    const bad = $$('[required]', f).find(i => !i.value.trim());
    if (bad) { e.preventDefault(); bad.focus(); bad.closest('label').classList.add('shake'); setTimeout(() => bad.closest('label').classList.remove('shake'), 600); toast('Lengkapi data yang bertanda *'); return; }
    $('.submit', f).classList.add('load');
  });
  // Pilihan jurusan dari modal (?j=ID)
  const pj = new URLSearchParams(location.search).get('j'), sj = $('select[name=jurusan_id]');
  if (pj && sj && !sj.value) sj.value = pj;

  // 7. Admin: angka naik, menu samping, pratinjau logo, konfirmasi hapus
  $$('[data-count]').forEach(el => {
    const to = +el.dataset.count; let n = 0; const step = Math.max(1, Math.ceil(to / 30));
    const t = setInterval(() => { n = Math.min(to, n + step); el.textContent = n; if (n >= to) clearInterval(t); }, 25);
  });
  const st = $('#stoggle'), side = $('#side');
  if (st) st.addEventListener('click', () => side.classList.toggle('open'));
  const li = $('#logo-in');
  if (li) li.addEventListener('change', () => {
    const file = li.files[0]; if (!file) return;
    const img = $('#logo-prev'); img.src = URL.createObjectURL(file); img.classList.remove('swap'); void img.offsetWidth; img.classList.add('swap');
  });
  $$('form[data-confirm]').forEach(fm => fm.addEventListener('submit', function (e) {
    if (fm.dataset.ok) return;
    e.preventDefault();
    const submitter = e.submitter;
    const ov = document.createElement('div'); ov.className = 'modal show';
    ov.innerHTML = `<div class="modal-box confirm-box"><h3>Konfirmasi</h3><p></p><div class="actions"><button class="btn btn-ghost-dark rip" data-n>Batal</button><button class="btn btn-blue rip" data-y>Ya, lanjutkan</button></div></div>`;
    $('p', ov).textContent = fm.dataset.confirm;
    document.body.appendChild(ov);
    const end = () => { ov.classList.remove('show'); setTimeout(() => ov.remove(), 300); };
    $('[data-n]', ov).onclick = end;
    ov.onclick = ev => ev.target === ov && end();
    $('[data-y]', ov).onclick = () => {
      fm.dataset.ok = 1;
      if (submitter && submitter.name) { const h = document.createElement('input'); h.type = 'hidden'; h.name = submitter.name; h.value = submitter.value; fm.appendChild(h); }
      fm.submit();
    };
  }));

  function toast(m) { const t = $('#toast'); if (!t) return; t.textContent = m; t.classList.add('show'); setTimeout(() => t.classList.remove('show'), 2600); }
})();
